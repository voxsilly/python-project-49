### Hexlet tests and linter status:
[![Actions Status](https://github.com/voxsilly/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/voxsilly/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/69c18eac89cf0bc5cca5/maintainability)](https://codeclimate.com/github/voxsilly/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/WPgiZf3Zce4J9Wg6AndhFw9X5.svg)](https://asciinema.org/a/WPgiZf3Zce4J9Wg6AndhFw9X5)
